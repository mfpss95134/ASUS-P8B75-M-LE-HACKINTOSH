# Kext-Droplet

### Simple Utility for installing kexts in macOS
- Update 27 Dec 2019 working 10.9 to 10.15

![Capture1](https://user-images.githubusercontent.com/6248794/71537765-e6ef6e80-28ee-11ea-8138-d647b66d0e01.png)
![Capture2](https://user-images.githubusercontent.com/6248794/71537766-e6ef6e80-28ee-11ea-9426-2a6677af1239.png)
![Capture3](https://user-images.githubusercontent.com/6248794/71537767-e6ef6e80-28ee-11ea-9759-9fc63a316900.png)
![Capture4](https://user-images.githubusercontent.com/6248794/71537768-e6ef6e80-28ee-11ea-82ae-ed7429c52391.png)
![Capture5](https://user-images.githubusercontent.com/6248794/71537769-e6ef6e80-28ee-11ea-8e2b-e361e727842f.png)
![Capture6](https://user-images.githubusercontent.com/6248794/71537770-e7880500-28ee-11ea-94bc-f839c6d47d9f.png)
![Capture7](https://user-images.githubusercontent.com/6248794/71537771-e7880500-28ee-11ea-9ec8-0cea2e143c5d.png)



#### Download Release V2 ➤ [Kext-Droplet.dmg.zip](https://github.com/chris1111/macOS-Mojave-USB-Restore/releases/tag/V2)
